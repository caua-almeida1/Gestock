import React, { useState, useEffect } from "react";
import { Icon } from "@iconify/react";
import "../../master/master.css";
import { ref, onValue } from "firebase/database";
import { database } from "../../../firebase/firebase";
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../../contexts/authContext';
import Sidebar from "../../../components/SidebarGestock";
import Calendar from "../../../components/calendar-production/Calendar";
import ScreenWarning from '../../../components/MaxPhone';

const Dashboard = () => {
  const [modules, setModules] = useState({});
  const [moduleDates, setModuleDates] = useState({});
  const [timeRemaining, setTimeRemaining] = useState({});
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  // Função para calcular o tempo restante
  const calculateTimeRemaining = (moduleKey) => {
    const releaseDate = moduleDates[moduleKey];
    if (!releaseDate) return null; // Se não houver data, retorna nulo

    const now = new Date();
    const releaseTime = new Date(releaseDate);
    const timeDiff = releaseTime - now;

    if (timeDiff <= 0) {
      return "Bloqueado";
    } else {
      const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));

      return `Faltam ${days}d ${hours}h ${minutes}m para liberar`;
    }
  };

  // Escuta mudanças no Firebase para estados e datas dos módulos
  useEffect(() => {
    const modulesRef = ref(database, 'moduleStates/');
    const datesRef = ref(database, 'moduleDates/');

    onValue(modulesRef, (snapshot) => {
      if (snapshot.exists()) {
        setModules(snapshot.val());
      } else {
        console.log("Nenhum dado disponível para os módulos.");
      }
    });


    onValue(datesRef, (snapshot) => {
      if (snapshot.exists()) {
        setModuleDates(snapshot.val());
      } else {
        console.log("Nenhum dado disponível para as datas dos módulos.");
      }
    });
  }, []);

  useEffect(() => {
    if (!currentUser) {
        navigate('/login'); // Redireciona para o login
    }
}, [currentUser, navigate]);

  // Atualiza o tempo restante para cada módulo
  useEffect(() => {
    const interval = setInterval(() => {
      const updatedTimes = {};

      Object.keys(moduleDates).forEach(moduleKey => {
        updatedTimes[moduleKey] = calculateTimeRemaining(moduleKey);
      });

      setTimeRemaining(updatedTimes);
    }, 1000);

    return () => clearInterval(interval);
  }, [moduleDates]);

  const formatModuleName = (moduleName) => {
    return moduleName.replace(/modulo(\d+)/i, 'Modulo $1');
  };
  
  const formatStatus = (status) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  return (
    <div className="dashboard">
      <Sidebar className="sidebar-container" />
      <div className="container-dashboard">
        <main>
          <h1>Dashboard</h1>

          {/* ======== ESQUERDA DO DASHBOARD ========*/}
          <div className="insights">
            {/* Renderizar dinamicamente os módulos */}
            {Object.keys(modules).map((moduleKey, index) => (
              <div key={index} className={`module-card-${index + 1}`}>
                <Icon 
                  icon={modules[moduleKey] === "bloqueado" ? "ic:round-lock" : "tabler:circle-check-filled"} 
                  className="icon" 
                />
                <div className="middle">
                  <div className="left">
                    <h3>{formatModuleName(moduleKey)}</h3>
                    <h1>{formatStatus(modules[moduleKey])}</h1>
                  </div>
                </div>
                <small className="text-muted">
                  {modules[moduleKey] === "bloqueado" 
                    ? timeRemaining[moduleKey] || "Bloqueado" 
                    : "Módulo liberado"}
                </small>
              </div>
            ))}
          </div>

          <div className="dashboard-users-card">
            <h2>Usuários</h2>
            <table>
              <thead>
                <tr>
                  <th>Nome </th>
                  <th>Atividades Concluídas</th>
                  <th>Cargo</th>
                  <th>Status</th>
                  <th>Detalhes</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Cauã Gonçalves</td>
                  <td>20</td>
                  <td>Administrador</td>
                  <td className="sucess-status-users">Online</td>
                  <td>
                    <Icon icon="mingcute:settings-1-fill" className="icon" />
                  </td>
                </tr>
                <tr>
                  <td>Samantha Alves</td>
                  <td>18</td>
                  <td>Administrador</td>
                  <td className="warning-status-users">Offline</td>
                  <td>
                    <Icon icon="mingcute:settings-1-fill" className="icon" />
                  </td>
                </tr>
                <tr>
                  <td>Rafael de Gino</td>
                  <td>15</td>
                  <td>Administrador</td>
                  <td className="warning-status-users">Offline</td>
                  <td>
                    <Icon icon="mingcute:settings-1-fill" className="icon" />
                  </td>
                </tr>
                <tr>
                  <td>Murilo Rodrigues</td>
                  <td>15</td>
                  <td>Comum</td>
                  <td className="sucess-status-users">Online</td>
                  <td>
                    <Icon icon="mingcute:settings-1-fill" className="icon" />
                  </td>
                </tr>
                <tr>
                  <td>Emilly Rodrigues</td>
                  <td>14</td>
                  <td>Comum</td>
                  <td className="sucess-status-users">Online</td>
                  <td>
                    <Icon icon="mingcute:settings-1-fill" className="icon" />
                  </td>
                </tr>
                <tr>
                  <td>Yollanda Moraes</td>
                  <td>13</td>
                  <td>Comum</td>
                  <td className="sucess-status-users">Online</td>
                  <td>
                    <Icon icon="mingcute:settings-1-fill" className="icon" />
                  </td>
                </tr>
                <tr>
                  <td>Luiz Felipe Dalbon.</td>
                  <td>9</td>
                  <td>Comum</td>
                  <td className="warning-status-users">Offline</td>
                  <td>
                    <Icon icon="mingcute:settings-1-fill" className="icon" />
                  </td>
                </tr>
              </tbody>
            </table>
            <a href="#">Mostrar Mais</a>
          </div>
        </main>

        {/* ======== DIREITA DO DASHBOARD ========*/}
        <div className="right">
          <div className="recent-updates">
            <h2>Atualizações</h2>
            <div className="updates">
              <div className="update">
                <div className="profile-photo">
                  <Icon icon="mingcute:user-4-fill" className="icon" />
                </div>
                <div className="message">
                  <p>
                    <b>Cauã Gonçalves</b> Editou sua empresa
                  </p>
                  <small className="text-muted">2 Minutos atrás</small>
                </div>
              </div>
              <div className="update">
                <div className="profile-photo">
                  <Icon icon="mingcute:user-4-fill" className="icon" />
                </div>
                <div className="message">
                  <p>
                    <b>Prof. Patrícia</b> Adicionou uma atividade
                  </p>
                  <small className="text-muted">2 Minutos atrás</small>
                </div>
              </div>
              <div className="update">
                <div className="profile-photo">
                  <Icon icon="mingcute:user-4-fill" className="icon" />
                </div>
                <div className="message">
                  <p>
                    <b>Bruno Gomes</b> Adicionou um evento
                  </p>
                  <small className="text-muted">2 Minutos atrás</small>
                </div>
              </div>
            </div>
          </div>

          <div className="calendar-dashboard">
            <h2> Calendário de Eventos </h2>

            <div>
              <Calendar className="calendar-dashboard" />
            </div>
          </div>
        </div>
      </div>
      {/* ======= LIMITE DE LARGURA ======= */}
      <ScreenWarning />
    </div>
  );
};

export default Dashboard;
